document.addEventListener("DOMContentLoaded", function () {
  const form = document.querySelector("form");
  if (!form) return;
  form.addEventListener("submit", function (e) {
    e.preventDefault();
    const data = new FormData(form);
    const obj = {};
    data.forEach((value, key) => obj[key] = value);

    fetch("https://script.google.com/macros/s/YOUR_SCRIPT_ID/exec", {
      method: "POST",
      body: JSON.stringify(obj),
    })
    .then(res => res.text())
    .then(txt => document.getElementById("result").innerText = txt || "ส่งสำเร็จแล้ว")
    .catch(err => alert("เกิดข้อผิดพลาด"));
  });
});
